packet = int(input("how big is the packet (in MB):"))
# user inputs size of packet
print (1337 < packet or packet > 2600)

